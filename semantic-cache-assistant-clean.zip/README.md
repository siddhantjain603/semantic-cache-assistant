# Semantic Cache Assistant

A customer-support AI assistant that uses semantic caching to reduce redundant LLM API calls, improve response latency, and optimize inference costs.

The project demonstrates how vector embeddings, Redis vector search, and LLM integration can work together to build a cost-efficient AI application.

## Overview

Semantic Cache Assistant identifies semantically similar user queries and reuses previously generated responses instead of invoking an LLM for every request.

### How It Works

1. Generate an embedding for the incoming query.
2. Search Redis for semantically similar cached queries.
3. Return the cached response if a sufficiently similar match is found.
4. If no suitable match exists, invoke the Groq LLM.
5. Store the newly generated response in the semantic cache.
6. Record request metrics, including cache hits, cache misses, LLM calls, and latency.
7. Return the response to the user.

## Tech Stack

| Component | Technology |
|---|---|
| Backend | Python, FastAPI, Uvicorn |
| Frontend | Streamlit |
| Cache | Redis Stack, RedisVL |
| Embeddings | Sentence Transformers |
| Embedding Model | all-MiniLM-L6-v2 |
| Embedding Dimensions | 384 |
| LLM Provider | Groq |
| LLM Model | openai/gpt-oss-120b |
| Environment Management | uv |
| Testing | Pytest, HTTPX |
| Code Quality | Ruff |
| Data Analysis | pandas |
| Infrastructure | Docker, Docker Compose |

## Architecture

```text
                         User
                           |
                           v
                  Streamlit Frontend
                           |
                           v
                     FastAPI Backend
                           |
                           v
                  Generate Embedding
                           |
                           v
                 Redis Semantic Cache
                           |
                    +------+------+
                    |             |
                 Cache Hit     Cache Miss
                    |             |
                    v             v
              Cached Answer    Groq LLM
                                  |
                             Generate Answer
                                  |
                             Store in Redis
                    |             |
                    +------+------+
                           |
                           v
                    Record Analytics
                           |
                           v
                      User Response
```

### Request Lifecycle

**Cache Hit**

- Convert the incoming query into an embedding.
- Search Redis for a sufficiently similar cached query.
- Return the previously generated response.
- Avoid making a new LLM request.
- Record a cache hit in analytics.

**Cache Miss**

- Convert the incoming query into an embedding.
- Search Redis and find no sufficiently similar cached query.
- Forward the request to the Groq LLM.
- Store the generated response in Redis.
- Record a cache miss and an LLM call.
- Return the generated response.

## Project Structure

```text
semantic-cache-assistant/
│
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   └── routes/
│   │   │       ├── health.py
│   │   │       ├── chat.py
│   │   │       ├── cache.py
│   │   │       └── analytics.py
│   │   ├── core/
│   │   │   ├── config.py
│   │   │   └── exceptions.py
│   │   ├── dependencies/
│   │   │   └── resources.py
│   │   ├── schemas/
│   │   │   ├── health.py
│   │   │   ├── chat.py
│   │   │   ├── cache.py
│   │   │   └── analytics.py
│   │   ├── services/
│   │   │   ├── semantic_cache.py
│   │   │   ├── vectorizer.py
│   │   │   ├── llm.py
│   │   │   ├── chat.py
│   │   │   └── analytics.py
│   │   └── main.py
│   └── tests/
│       ├── test_health.py
│       ├── test_chat.py
│       ├── test_cache.py
│       ├── test_analytics.py
│       └── test_analytics_api.py
│
├── frontend/
├── data/
├── scripts/
├── results/
├── .env.example
├── .gitignore
├── .python-version
├── README.md
├── docker-compose.yml
├── pyproject.toml
└── uv.lock
```

## Getting Started

### Prerequisites

- Python 3.13
- uv
- Docker Desktop
- Groq API key

### 1. Clone the Repository

```bash
git clone https://github.com/siddhantjain603/semantic-cache-assistant.git
cd semantic-cache-assistant
```

### 2. Install Dependencies

```bash
uv sync --dev
```

### 3. Configure Environment Variables

Create your local environment file:

```bash
cp .env.example .env
```

Add your Groq API key:

```env
GROQ_API_KEY=your_groq_api_key
```

| Variable | Default / Purpose |
|---|---|
| `APP_NAME` | Semantic Cache Assistant |
| `APP_VERSION` | 0.1.0 |
| `DEBUG` | True |
| `REDIS_URL` | redis://localhost:6379 |
| `GROQ_API_KEY` | Your Groq API key |
| `GROQ_MODEL` | openai/gpt-oss-120b |
| `EMBEDDING_MODEL` | sentence-transformers/all-MiniLM-L6-v2 |
| `EMBEDDING_DIMENSION` | 384 |
| `CACHE_NAME` | semantic-cache-assistant |
| `CACHE_DISTANCE_THRESHOLD` | 0.30 |
| `CACHE_TTL` | 86400 seconds |

Never commit your actual `.env` file or API keys to GitHub.

### 4. Start Redis

```bash
docker compose up -d
```

Verify the Redis container:

```bash
docker ps
```

Verify Redis connectivity:

```bash
docker exec -it semantic-cache-redis redis-cli ping
```

Expected output:

```text
PONG
```

### 5. Start the Backend

```bash
uv run uvicorn backend.app.main:app --reload
```

Backend URL: `http://127.0.0.1:8000`

Swagger API documentation: `http://127.0.0.1:8000/docs`

### 6. Run Tests

```bash
uv run python -m pytest backend/tests/ -v
```

Run code-quality checks:

```bash
uv run ruff check .
```

## API Endpoints

| Method | Endpoint | Description | Status |
|---|---|---|---|
| GET | `/health` | Application health check | Implemented |
| POST | `/chat` | Submit a question and retrieve a cached or generated answer | Implemented |
| GET | `/cache` | Retrieve cached entries with pagination | Implemented |
| GET | `/analytics` | Retrieve cache and request analytics | Implemented |

### 1. Health Check

```http
GET /health
```

Checks application health.

### 2. Chat API

```http
POST /chat
```

Request:

```json
{
    "question": "What is semantic caching?"
}
```

Example response:

```json
{
    "answer": "Semantic caching stores and retrieves responses using semantic similarity.",
    "cache_hit": false,
    "matched_question": null,
    "distance": null
}
```

| Field | Description |
|---|---|
| `answer` | Generated or cached answer |
| `cache_hit` | Whether the response came from the cache |
| `matched_question` | Original cached question when a match exists |
| `distance` | Semantic distance of the matched cache entry |

### 3. Cache Management API

```http
GET /cache
```

Retrieves cached entries from Redis with pagination.

| Parameter | Default | Constraints |
|---|---:|---|
| `offset` | 0 | Greater than or equal to 0 |
| `limit` | 20 | Between 1 and 100 |

Example:

```http
GET /cache?offset=0&limit=20
```

Example response:

```json
{
    "entries": [
        {
            "id": "cache:example",
            "question": "What is semantic caching?",
            "answer": "Semantic caching stores responses for similar queries.",
            "inserted_at": 1795341127.36,
            "updated_at": 1795341127.36
        }
    ],
    "total_entries": 1,
    "returned_entries": 1,
    "offset": 0,
    "limit": 20
}
```

| Field | Description |
|---|---|
| `entries` | Retrieved cache records |
| `total_entries` | Total number of indexed cache records |
| `returned_entries` | Number of records in the current response |
| `offset` | Current pagination offset |
| `limit` | Maximum records requested |

### 4. Analytics API

```http
GET /analytics
```

Returns application-level request and cache analytics.

Example response:

```json
{
    "total_requests": 10,
    "cache_hits": 7,
    "cache_misses": 3,
    "llm_calls": 3,
    "hit_rate": 70.0,
    "miss_rate": 30.0,
    "total_latency_ms": 2500.0,
    "average_latency_ms": 250.0
}
```

| Field | Description |
|---|---|
| `total_requests` | Total requests processed |
| `cache_hits` | Requests served from cache |
| `cache_misses` | Requests requiring LLM fallback |
| `llm_calls` | Number of LLM calls |
| `hit_rate` | Percentage of cache hits |
| `miss_rate` | Percentage of cache misses |
| `total_latency_ms` | Accumulated request latency |
| `average_latency_ms` | Average request latency |

Analytics are stored separately in Redis using a dedicated analytics key, so clearing the semantic cache through its cache-management mechanisms does not automatically erase analytics data.

## Error Handling

The application uses centralized exception handling in FastAPI.

The following service errors are translated into HTTP 503 responses:

| Exception | Source |
|---|---|
| `ServiceUnavailableError` | Application services |
| `RedisError` | Redis client |
| `RedisSearchError` | RedisVL search operations |

Example error response:

```json
{
    "detail": "A required service is currently unavailable."
}
```

The application also validates pagination parameters and returns HTTP 422 for invalid values.

## Current Implementation Status

### Milestone 1 — Backend Foundation

**Status: COMPLETED**

- [x] Initialize project structure.
- [x] Configure Python environment using uv.
- [x] Install application and development dependencies.
- [x] Configure Redis Stack using Docker Compose.
- [x] Verify Redis vector search module.
- [x] Implement application configuration.
- [x] Implement shared Redis and embedding resources.
- [x] Initialize FastAPI application and lifespan management.
- [x] Implement health endpoint.
- [x] Implement RedisVL semantic cache.
- [x] Integrate Sentence Transformer embeddings.
- [x] Integrate Groq LLM fallback.
- [x] Implement lazy LLM client initialization.
- [x] Implement ChatService orchestration.
- [x] Implement chat request and response schemas.
- [x] Implement POST `/chat`.
- [x] Add automated health and chat API tests.
- [x] Verify exact-match cache hits.
- [x] Verify semantic cache hits using paraphrased queries.
- [x] Verify cache misses and LLM fallback through the live API.

### Milestone 2 — Cache Management and Analytics

**Status: COMPLETED**

- [x] Inspect RedisVL cache management and inspection APIs.
- [x] Design application-level cache statistics.
- [x] Track total requests.
- [x] Track cache hits and cache misses.
- [x] Calculate cache hit rate and miss rate.
- [x] Track LLM API calls.
- [x] Measure request latency.
- [x] Implement analytics service.
- [x] Implement GET `/analytics`.
- [x] Implement cached-entry inspection.
- [x] Implement pagination for cache entries.
- [x] Include total cache-entry count.
- [x] Implement GET `/cache`.
- [x] Handle uninitialized cache and service states.
- [x] Implement centralized Redis and RedisVL exception handling.
- [x] Add automated tests for cache and analytics APIs.
- [x] Verify HTTP 503 behavior for Redis failures.
- [x] Run complete backend test suite.
- [x] Run full-project Ruff checks.

**Milestone 2 verification:**

- 20 automated backend tests passing.
- Full-project Ruff checks passing.
- Redis and RedisVL error handling verified through API tests.
- Cache inspection and pagination verified.

## Development Roadmap

This is the project's master execution plan. Milestones should be completed in sequence unless a documented engineering dependency requires a change.

### Milestone 3 — Testing and Reliability

**Status: NEXT**

- [ ] Add deeper unit tests for ChatService.
- [ ] Test semantic cache hit behavior.
- [ ] Test semantic cache miss behavior.
- [ ] Test LLM fallback and response storage.
- [ ] Test lazy LLM initialization.
- [ ] Test Groq API failures and timeouts.
- [ ] Test Redis connection failures against a real Redis instance.
- [ ] Test invalid requests and edge cases.
- [ ] Add integration tests for Redis and the complete request pipeline.
- [ ] Evaluate concurrent requests and race conditions.
- [ ] Improve error handling and application reliability.

### Milestone 4 — Evaluation and Benchmarking

**Status: PLANNED**

- [ ] Design a representative query evaluation dataset.
- [ ] Include exact-match queries.
- [ ] Include semantically similar queries.
- [ ] Include unrelated queries.
- [ ] Evaluate different cosine-distance thresholds.
- [ ] Measure cache hit rate and miss rate.
- [ ] Measure false-positive and false-negative rates.
- [ ] Measure semantic matching accuracy.
- [ ] Compare cache-hit and cache-miss latency.
- [ ] Measure average LLM response latency.
- [ ] Estimate LLM API calls avoided.
- [ ] Estimate cost savings.
- [ ] Generate benchmark reports and visualizations.
- [ ] Document threshold selection and trade-offs.

### Milestone 5 — Streamlit Frontend

**Status: PLANNED**

- [ ] Build the main Streamlit application.
- [ ] Implement an interactive chat interface.
- [ ] Connect the frontend to the FastAPI backend.
- [ ] Display cache-hit and cache-miss status.
- [ ] Display matched questions and semantic distance.
- [ ] Build a cache statistics dashboard.
- [ ] Add cache management controls.
- [ ] Build evaluation and benchmarking visualizations.
- [ ] Add suitable configuration controls.
- [ ] Improve UI usability and error handling.

### Milestone 6 — Production Engineering and Deployment

**Status: PLANNED**

- [ ] Complete Docker Compose configuration.
- [ ] Containerize the FastAPI backend.
- [ ] Containerize the Streamlit frontend.
- [ ] Configure Redis persistence.
- [ ] Add service health checks.
- [ ] Improve environment-based configuration.
- [ ] Add structured logging.
- [ ] Add monitoring and operational metrics.
- [ ] Implement API security and rate limiting.
- [ ] Add GitHub Actions CI pipeline.
- [ ] Validate deployment configuration.
- [ ] Perform end-to-end deployment testing.

### Milestone 7 — Documentation and Final Release

**Status: PLANNED**

- [ ] Create a complete system architecture diagram.
- [ ] Document application design and request lifecycle.
- [ ] Document API endpoints and schemas.
- [ ] Document configuration and setup instructions.
- [ ] Document benchmark methodology and results.
- [ ] Document design decisions and trade-offs.
- [ ] Add frontend screenshots.
- [ ] Add a project demonstration.
- [ ] Perform final end-to-end verification.
- [ ] Publish a tagged GitHub release.

## Future Enhancements

Features not included in the current implementation but worth considering:

- Cache clearing endpoint.
- Cache expiration and TTL management controls.
- More detailed cache lookup latency tracking.
- LLM calls avoided and estimated cost savings.
- Configurable semantic distance threshold through the frontend.
- Detailed operational monitoring.

## Evaluation Metrics

The project will measure:

| Metric | Purpose |
|---|---|
| Cache hit rate | Percentage of requests served from cache |
| Cache miss rate | Percentage of requests requiring fallback |
| Semantic match accuracy | Correctness of semantic retrieval |
| False-positive rate | Incorrect cache matches |
| False-negative rate | Relevant matches missed by the cache |
| Cache lookup latency | Time spent searching Redis |
| LLM response latency | Time spent generating a new response |
| Overall response latency | End-to-end request time |
| LLM calls avoided | Reduction in external LLM requests |
| Estimated cost savings | Financial impact of caching |

Benchmark results will be added after the evaluation framework is implemented.

## Development Principles

To maintain engineering quality and avoid drifting from the project plan:

1. Complete milestones in the documented sequence.
2. Work incrementally and verify each implementation step.
3. Add automated tests for new functionality.
4. Run Ruff and the complete test suite before milestone completion.
5. Document important architectural decisions and trade-offs.
6. Commit and push completed milestones to GitHub.
7. Never mark a feature complete without testing it.
8. Keep benchmark claims backed by measured results rather than assumptions.

## License

This project is licensed under the MIT License.

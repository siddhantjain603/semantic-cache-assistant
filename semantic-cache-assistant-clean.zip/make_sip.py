# make_zip.py - Put this INSIDE semantic-cache-assistant folder
import zipfile
from pathlib import Path

ROOT = Path(r"C:\Users\ooo\padho-ai-engineer\mini_projects\semantic-cache-assistant")
OUTPUT = ROOT / "semantic-cache-assistant-clean.zip"

EXCLUDE_DIRS = {".venv", ".git", ".pytest_cache", ".ruff_cache", "__pycache__", ".mypy_cache", "node_modules", ".streamlit"}
EXCLUDE_FILES = {".env", "make_zip.py", OUTPUT.name}
EXCLUDE_EXTS = {".pyc", ".pyo"}

count = 0
skipped = 0

with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED) as z:
    for file in ROOT.rglob("*"):
        if not file.is_file():
            continue
        if any(part in EXCLUDE_DIRS for part in file.parts):
            continue
        if file.name in EXCLUDE_FILES:
            continue
        if file.suffix in EXCLUDE_EXTS:
            continue
        if file == OUTPUT:
            continue
        
        try:
            z.write(file, file.relative_to(ROOT))
            count += 1
        except (PermissionError, OSError) as e:
            print(f"Skipped (locked): {file.name}")
            skipped += 1

print(f"✅ Created {OUTPUT}")
print(f"Included {count} files, skipped {skipped}")
print("⚠️  .env and .venv excluded")